<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<link rel="stylesheet" href="styleAcceuil.css">
<title>Gestion PING 2021/2022</title>
</head>
<body>
<nav>
<ul>
  <li><a class="active" href="index.php"><img src="https://media-exp1.licdn.com/dms/image/C4D0BAQHDcMd0iFuTeg/company-logo_200_200/0/1519892537247?e=2159024400&v=beta&t=Y_hTdGPgp5IENW2N_QVjA_WCEcruQe-9kzoFXRzBZ3Y" alt="Photo de l'école"  width="50" height="50" border="0"/></a></li>
  <li><a class="Créer" href="creation.php" height="50" width="50">Créer profil</a></li>
  <li><a class="connecter" href="authentification.php" height="50" width="50">Se connecter</a></li>
  <li><a href="https://www.esigelec.fr/fr"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Globe_icon.svg/1024px-Globe_icon.svg.png" alt="internet" height="50" width="50"></a></li>
  <li><a href="https://twitter.com/groupeesigelec"><img src="https://assets.stickpng.com/images/580b57fcd9996e24bc43c53e.png" alt="twitter" height="50" width="50"></a></li>
  <li><a href="https://www.facebook.com/Page.ESIGELEC"><img src="https://fsu83.fsu.fr/wp-content/uploads/sites/56/2017/10/Facebook-logo.png" alt="facebook" height="50" width="50"></a></li>

  <div class="logoécole">
</div>
  <div class="internet">
    </div>
</a>
<div class="twitter">
    </div>
</a>
    <div class="facebook">
    </div>
</a>
</ul>
</nav>


<main>
<br>
<br>
<br>
<br>
<br>
<br>
    <div class="imageB">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAb1BMVEUAAAD///9HR0dlZWULCwswMDC+vr5zc3Pn5+f09PQpKSlpaWnw8PBgYGD39/fi4uJ9fX2urq5AQEA1NTVTU1NZWVmpqamPj4+enp6FhYVOTk7JyckUFBTV1dUjIyOXl5ccHBzR0dGbm5u/v78XFxcZPZVZAAAEX0lEQVR4nO3daUOyQBQFYHBLzSU1tcwWq///G99cCpg7vALOBc/1nG+CwjxBOptOdN8ynqgVWQ+F+KEQPxTih0L8UIgfCvFDIX4oxA+F+KEQPxTih0L8UIgfCvFDIX4oxA+F+KEQPxTih0L8UBgq3/Nx+8IsF50qZ65F2O714yCZrualT16DcD0Iwzsh70ueXl24HIX07fP6VqoA2sKn0L59Sl1GZWFPAxjHzyWKoCtUAsbxQ/EyqArftYBx/Fi4EJrCjR4wHlyFcKoojGdXIHzQBMZxt3lhoHpMXnqNC5eZ8ryMt5ce8OMhc9tPCr5MTzhLF6dsVSsnTxWOqSechgdm/2wF32v0hKmyfIU7aqqW+1rsFWrCRUoY8CTr1GGLvUJNOE5KMgp42MfrEd4lJekHPGw3JSzW5KewciisGAplKKwcCiumWWFrvElOalC43lcZJ3/VYXvCF4djTrj7O+/uuMGa8Ct14vFhizFhpuf3+K9oS5jt2j7epqaETt+9PeEsC7R3l64cYLw5bLYjFAOEp24nM0IBnJ52WBF+5gGtCNe5QCNCAewba1s8C2Bq9MWCUIwPjtKnNCC8E8Btzm5QoQQO8/ZjCu9d4MAZdUYXjl2gGFYHF0rg0H0KtnApgHJSJLTwUQA9R0EWyqlOG8+zgIWtQsB0fSDkGHANwrkA+ifRfSQ/sFl+5nJ+9IWLiQscly/mBVEXSmCwqTLFoi0ciknpNQO1hW9NX0Ft4VZcwRKTkQNFVbgV3ysoM6E8UDSFHTFftAGgqlAA679FI1Wh8ozfnwbm7LtRoeqs9FMm3upfTcLXGoA/xI/GhKJrWynnp/1qCcUnvVLOz05XEsomr1aaErbNC2W/jFKmZ4uiJOzU9X94vpak9U7jDtUrZXe+JFrCTvAv8/pS5GsZap/4b6LhNJj1wmZVoEajWWuTjd9GKt6aNW95FdeVi3lBNFtP3asgqrbxu+JGbYCo208zdIUNtPKV+9rkVaz97Ua7v1R2CNd9FdX7vOdNE/XHLeTATM6Nuh0mKXmO/6WRsac77/NwR9eKEoFHSD1DpL4bFVnoIXquIrSwEBFb6JmsIIbZwIUeonsV0YWeDkaHCC/0ELM3Kr7QQ8zMyjAg9PSipokWhJ4Ziu1kpwmhh5hcRRtCD3H5u8uI0EP8neVmRegZljoRzQjllPbJccKBHaEkrg6bDQkF8diktyR0icfBeFNC5/szFoVZYt/dZEGYIX66W0wIU6CRu8GI8E80WGQf2xFGrd1kP/b9+9CgMIq+N6mjmRRmQmHFUChDYeVQWDEUylBYORRWDIUyFFaO/d/zVvpN9vfrEdr/Xf0bWBvB/voW9tcosb/OzA2sFWR/vacbWLPL/rprN7B23g2sf3gDa1jewDqkkf21ZPexvh7wIVvbazo3GgrxQyF+KMQPhfihED8U4odC/FCIHwrxQyF+KMQPhfihED8U4odC/FCIHwrxQyF+KMQPhfihED7/AJQBPL08DiqbAAAAAElFTkSuQmCC"  height="230" width="230">
    </div>  
    <br>
<br>
<br>
<br>
    <div class="dec">
        <?php
        
       echo "Déconnexion réussi: ";
       echo "Veuillez cliquer sur le bouton ci-dessous pour retourner à la page d'accueil.";
          ?>
        </div>
        

<div class="retour">
    <a href="index.php" ><button>Quitter</button></a>
        <br/>    
    </a>
</div>

</main>
    <footer>
        <div class="footer-dark">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 item text">  
                        Contact:<br>
                        ANSEUR Adel: adel.anseur@groupe-esigelec.org<br>
                        PLAYT Antoine: antoine.playt@groupe-esigelec.org<br>          
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">ANSEUR PLAYT © 2021</p>
            </div>
        </footer>
</body>
</html>
