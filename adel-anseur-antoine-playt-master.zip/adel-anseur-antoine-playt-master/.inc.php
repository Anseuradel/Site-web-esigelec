<?php
define ('SERVEUR',"localhost");
define ('LOGIN',"grp_8_1");
define ('MDP',"Bothah8kuG");
define ('BDD',"bdd_8_1");
?>
